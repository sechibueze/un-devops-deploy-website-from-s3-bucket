Deploy Static Website on AWS

Customized:
- Brand name and hero image to match a local startup offering tour guide services
- content to match brand identity and marketing efforts
- Footer links to open my github, facbook in a new tab

S3 bucket endpoint
https://sechibueze-wakamania-bucket.s3.amazonaws.com/index.html

Website endpoint
http://sechibueze-wakamania-bucket.s3-website-us-east-1.amazonaws.com/

CloudFront endpoint
d2vg8bnf7m77kn.cloudfront.net




